/**
 * Created by huangyh(黄永号) on 2019/07/03.
 */
//km360 app : 性别[1:男,0:女,9:未说明的性别]
export default [
    {
        key: "male",
        text: "男",
        value: 1,
        icon: "icon-male-off",
        activeIcon: "icon-male-on"
    },
    {
        key: "female",
        text: "女",
        value: 0,
        icon: "icon-female-off",
        activeIcon: "icon-female-on"
    }
];