/**
 * Created by huangyh(黄永号) on 2019/07/13.
 */

const module = {
    state: {
        date: ""
    },
    mutations: {
        SET_DATE: (state, date) => {
            state.date = date
        }
    },
    actions: {}
};

export default module;
