/**
 * Created by huangyh(黄永号) on 2019/07/03.
 */

let global = {
    getPersonInfo: "/api/Person/GetPersonInfo",
    getCurrentAddress: "/api/PersonArea/GetCurrentAddress"
};

export default global;
