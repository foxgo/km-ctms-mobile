/**
 * Created by huangyh(黄永号) on 2019/07/03.
 */

import global from "./global";

//不需要token请求的api
let api = {
    ...global
};

export default api;
