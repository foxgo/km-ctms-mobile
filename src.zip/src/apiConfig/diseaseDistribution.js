/**
 * Created by huangyh(黄永号) on 2019/07/03.
 */

let global = {
    getIllnessList: "/api/Histogram/IllnessList",
    getProvinceList: "/api/Histogram/ProvinceList"
};

export default global;
