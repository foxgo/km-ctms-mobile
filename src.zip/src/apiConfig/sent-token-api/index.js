/**
 * Created by huangyh(黄永号) on 2019/07/03.
 */

//如果有token就发送，没有就不发送token请求的api
let api = {};

export default api;
